public class compare {
    public static void main(String[] args) {
        int grade = 80;
        int numberDaysAbsent = 0;
        if(!(grade >= 88)){
            if(numberDaysAbsent == 0){
                System.out.println("You Qualify for the scholarship");
            }
            else
                System.out.println("You aren't Quality for the scholarship");
        }else {
                System.out.println("You aren't Quality for the scholarship");
        }
    }
}
