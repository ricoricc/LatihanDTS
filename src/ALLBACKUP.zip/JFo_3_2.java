public class JFo_3_2 {
    public static void main(String[] args) {
        long angka = 1000000000000000000l;

        int a = 10;
        a+=5;

    }
}
