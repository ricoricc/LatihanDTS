public class ProblemSet2_1 {
    public static void main(String args[]) {
        String greet1 = "Hello";
        String greet2 = "World";
        String message2 = greet1 +" " +greet2 +" " +2016 +"!";
        System.out.println(message2);
    }
}
